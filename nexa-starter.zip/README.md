# Nexa

Nexa is a bilingual (Arabic/English) web platform and Telegram Mini App starter for messaging, multi-vendor commerce, and AI-assisted shopping.

> Status: foundation scaffold. Payment providers, Telegram authentication verification, realtime messaging, and AI provider integrations must be configured and tested before production use.

## Product scope

- Arabic RTL and English LTR foundations
- Web app and Telegram Mini App entry points
- Accounts and role-aware authorization
- Multi-vendor stores, products, inventory, carts, orders, reviews
- Buyer/seller conversations and notifications
- Online payments and cash on delivery (COD)
- AI shopping assistant behind a provider adapter
- Admin moderation, reports, and audit trail

## Suggested stack

- Next.js App Router + TypeScript
- PostgreSQL + Prisma
- Zod for input validation
- Vitest for unit tests
- Playwright for end-to-end tests
- A managed object-storage service for product media
- A queue/cache such as Redis when background jobs are introduced

## Requirements

- Node.js 20+
- npm 10+
- PostgreSQL 15+ (or a compatible managed PostgreSQL service)

## Local setup

1. Copy `.env.example` to `.env` and set local values. Never commit `.env`.
2. Install dependencies: `npm install`
3. Generate Prisma client: `npm run db:generate`
4. Apply schema to a local database: `npm run db:migrate`
5. Start development server: `npm run dev`
6. Run unit tests: `npm test`

The app intentionally avoids pretending that payment, Telegram identity verification, or AI calls work without credentials and server-side integrations.

## Environment

See `.env.example`. Do not put private keys in browser-exposed variables. Only variables prefixed with `NEXT_PUBLIC_` are exposed to the browser.

## Telegram Mini App security checklist

- Validate Telegram `initData` on the server using Telegram's documented verification procedure.
- Reject stale authentication payloads and rate-limit verification endpoints.
- Never trust user IDs, roles, prices, totals, or order status supplied by the client.
- Keep bot tokens and payment secrets server-side.
- Use HTTPS in production and validate allowed origins.

## Payments

Implement a provider adapter and verify signed webhooks on the server. Make order/payment state changes idempotent. A browser redirect is not proof of payment. COD orders should use a distinct payment state and require delivery confirmation before being marked paid.

## Database

The Prisma schema in `prisma/schema.prisma is the initial relational model. It covers identity, stores, products, carts, orders, payments, conversations, messages, reviews, and audit events. Review indexes, retention, and regional/legal requirements before production.

## Testing strategy

See `docs/TEST_PLAN.md` for unit, integration, security, and end-to-end cases.

## Proposed structure

```text
src/
  app/
    [locale]/
      page.tsx
      layout.tsx
    api/health/route.ts
  components/
  features/
    auth/
    catalog/
    stores/
    cart/
    orders/
    payments/
    messaging/
    ai/
  lib/
    env.ts
    i18n.ts
    prisma.ts
prisma/
  schema.prisma
messages/
  ar.json
  en.json
docs/
  ARCHITECTURE.md
  TEST_PLAN.md
```

## Roadmap

1. Foundation, localization, health endpoint, schema, CI
2. Server-verified identity and authorization
3. Catalog, stores, inventory, cart, order lifecycle
4. Buyer/seller messaging and notifications
5. Payment provider + COD workflow, webhook verification
6. AI assistant with safety, privacy, rate limits, and cost controls
7. Admin tools, monitoring, backups, load/security tests

## License

No license has been selected. Add one before public distribution.
