# Nexa test plan

## Unit tests

- Locale selection: Arabic is RTL; English is LTR.
- Input validation rejects malformed product prices, quantities, addresses, and messages.
- Price calculations use integer minor units and reject negative values.
- Role and ownership policies reject unauthorized store/product/order mutations.
- Order status transitions only allow explicitly permitted transitions.

## Integration tests (PostgreSQL test database)

- User can create a cart and add an active product.
- Inactive products cannot be purchased.
- Order creation snapshots product title and unit price.
- Concurrent purchases cannot oversell inventory.
- Idempotency key prevents duplicate order creation.
- Seller can see only their store's orders and items.
- Buyer can see only their own orders.
- Conversation members can read/send messages; non-members cannot.
- Payment webhook signature is checked before any state mutation.
- Duplicate webhook delivery does not double-apply a payment.
- COD orders remain unpaid until the fulfillment policy confirms delivery/collection.

## End-to-end tests (Playwright)

1. Open `/ar` and confirm Arabic direction and primary content.
2. Open `/en` and confirm English direction.
3. Confirm language links navigate correctly.
4. Check health endpoint returns HTTP 200 and JSON status `ok`.
5. Once commerce UI is implemented: browse product, add to cart, place COD order.
6. Once online payments are implemented: test provider sandbox success, failure, cancellation, and duplicate webhook.
7. Once Telegram integration is implemented: test valid, invalid, expired, and replayed `initData`.

## Security tests before production

- IDOR tests across users, stores, orders, and conversations.
- CSRF/origin protections where applicable; XSS and content sanitization.
- Rate limiting for login, search, messaging, checkout, and AI endpoints.
- Upload MIME/size limits and malware/content checks.
- Secrets scan and dependency audit.
- Authorization tests for admin-only actions.
- Load test catalog/search and checkout; test backup restore.

## Release gates

- `npm run lint`
- `npm run typecheck`
- `npm test`
- `npm run build`
- `npm run test:e2e` with a configured test database
- No unresolved critical/high security findings
- Payment and Telegram sandbox flows independently verified
