# Nexa architecture

## Boundaries

- **Identity & access:** users, roles, verified Telegram identity, sessions, authorization.
- **Marketplace:** stores, products, inventory, search, reviews.
- **Commerce:** cart, price calculation, order snapshots, order lifecycle.
- **Payments:** provider adapter, signed webhook verification, idempotency, refunds.
- **Messaging:** conversations, membership checks, message delivery and moderation.
- **AI:** provider adapter, rate limits, privacy controls, usage/cost tracking.
- **Operations:** admin moderation, audit log, observability, backups.

## Important design rules

1. Store money as integer minor units (e.g. piasters for EGP); never use floating-point money.
2. Recalculate price and stock on the server in a database transaction when placing orders.
3. Snapshot product title and unit price into `OrderItem` so historical orders remain meaningful.
4. Process provider webhooks idempotently and verify signatures before changing payment state.
5. Keep payment secrets, bot tokens, and AI API keys server-side.
6. Verify conversation membership for every message read/write.
7. Apply authorization at the API boundary; never trust a client-provided role or owner ID.
8. Use pagination, rate limits, request validation, and structured logs.
9. Add a separate fulfillment/shipment model before integrating multiple carriers.
10. Review deletion, privacy, and retention policies before launch.

## Scale path

Start with one deployable application and a managed PostgreSQL database. Add Redis for rate limiting/queues and a worker for emails, notifications, media processing, and webhook retries when workload justifies it. Split services only when team ownership or measured scaling needs warrant it.

## Open design decisions

- Payment provider and marketplace split-payout capability
- Shipping carriers and return policies
- Media storage and content moderation provider
- Realtime transport/provider
- AI provider, retention rules, and user consent
- Legal entity, seller verification, tax and consumer-protection obligations
