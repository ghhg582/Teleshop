# Scaffold status

Implemented in this starter:
- Bilingual landing routes with Arabic RTL and English LTR
- Health endpoint
- Initial Prisma data model
- Environment template with no real credentials
- Unit and Playwright test examples
- CI workflow and architecture/test documentation

Not yet implemented:
- Registration/login and server-verified Telegram initData
- Product CRUD, cart API, checkout and order services
- Realtime chat transport
- Payment provider adapter and signed webhook endpoint
- AI provider integration
- Admin dashboard, seller verification, shipment integrations
- Production rate limiting, monitoring, backups and deployment config

Do not use this scaffold as a production marketplace until these items are implemented and reviewed.
