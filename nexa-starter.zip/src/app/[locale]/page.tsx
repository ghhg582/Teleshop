const copy = {
  ar: {
    eyebrow: "منصة واحدة، تجارب متعددة",
    title: "أهلًا بك في Nexa",
    description: "تواصل، اكتشف المتاجر، وتسوق بذكاء — من الويب أو داخل تيليجرام.",
    market: "السوق الإلكتروني",
    chat: "المحادثات",
    ai: "مساعد التسوق الذكي",
    note: "هذه نسخة تأسيسية. تسجيل الدخول والدفع والمحادثات الفعلية تحتاج إلى ربط الخدمات والتحقق منها قبل الإطلاق.",
  },
  en: {
    eyebrow: "One platform, many experiences",
    title: "Welcome to Nexa",
    description: "Connect, discover stores, and shop smarter — on the web or inside Telegram.",
    market: "Marketplace",
    chat: "Messaging",
    ai: "AI shopping assistant",
    note: "This is a foundation scaffold. Authentication, payments, and live messaging require configured integrations and verification before launch.",
  },
} as const;

export default async function Home({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (locale !== "ar" && locale !== "en") return null;
  const t = copy[locale];

  return (
    <main style={{
      minHeight: "100vh", padding: "clamp(24px, 6vw, 80px)",
      color: "#172033", background: "linear-gradient(145deg,#f8fbff,#edf3ff)",
      direction: locale === "ar" ? "rtl" : "ltr"
    }}>
      <nav style={{display:"flex", justifyContent:"space-between", alignItems:"center", maxWidth:1100, margin:"0 auto 72px"}}>
        <strong style={{fontSize:28, letterSpacing:"-1px"}}>Nexa<span style={{color:"#536dfe"}}>.</span></strong>
        <div style={{display:"flex", gap:12}}>
          <a href="/ar" aria-label="العربية">العربية</a>
          <a href="/en" aria-label="English">English</a>
        </div>
      </nav>
      <section style={{maxWidth:1100, margin:"0 auto"}}>
        <p style={{color:"#536dfe", fontWeight:700}}>{t.eyebrow}</p>
        <h1 style={{fontSize:"clamp(42px,7vw,76px)", lineHeight:1.1, maxWidth:850, margin:"12px 0 24px"}}>{t.title}</h1>
        <p style={{fontSize:20, lineHeight:1.8, maxWidth:720, color:"#536078"}}>{t.description}</p>
        <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(210px,1fr))", gap:16, marginTop:44}}>
          {[t.market,t.chat,t.ai].map((item) => (
            <article key={item} style={{background:"white", border:"1px solid #e2e8f5", borderRadius:20, padding:24, boxShadow:"0 12px 40px #263b6b0d"}}>
              <div style={{width:42,height:42,borderRadius:12,background:"#eef0ff",marginBottom:18}} />
              <h2 style={{fontSize:20, margin:0}}>{item}</h2>
            </article>
          ))}
        </div>
        <p style={{marginTop:36, fontSize:14, lineHeight:1.8, color:"#647089"}}>{t.note}</p>
      </section>
    </main>
  );
}
