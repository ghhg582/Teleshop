import { describe, expect, it } from "vitest";
import { directionFor, isLocale } from "./i18n";

describe("localization helpers", () => {
  it("accepts supported locales only", () => {
    expect(isLocale("ar")).toBe(true);
    expect(isLocale("en")).toBe(true);
    expect(isLocale("fr")).toBe(false);
  });

  it("uses RTL for Arabic and LTR for English", () => {
    expect(directionFor("ar")).toBe("rtl");
    expect(directionFor("en")).toBe("ltr");
  });
});
