import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  APP_URL: z.string().url().default("http://localhost:3000"),
  DATABASE_URL: z.string().min(1).optional(),
  TELEGRAM_BOT_TOKEN: z.string().optional(),
  PAYMENT_PROVIDER: z.string().default("disabled"),
  AI_PROVIDER: z.string().default("disabled"),
});

export const env = schema.parse({
  NODE_ENV: process.env.NODE_ENV,
  APP_URL: process.env.APP_URL,
  DATABASE_URL: process.env.DATABASE_URL,
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN,
  PAYMENT_PROVIDER: process.env.PAYMENT_PROVIDER,
  AI_PROVIDER: process.env.AI_PROVIDER,
});
